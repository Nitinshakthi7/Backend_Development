// Enhanced updateStats with counter animation
function updateStats(data) {
  // Animate today's usage counter
  const todayUsageElement = document.getElementById('todayUsage');
  const todayValue = data.totals.totalConsumption || 0;
  animateCounter(todayUsageElement, todayValue);

  // Animate total cost counter
  const totalCostElement = document.getElementById('totalCost');
  const costValue = data.totals.totalCost || 0;
  animateCounter(totalCostElement, costValue);

  // Animate carbon footprint counter
  const carbonElement = document.getElementById('carbonKg');
  const carbonValue = parseFloat(data.carbonFootprint.co2kg);
  animateCounter(carbonElement, carbonValue);

  // Update other elements
  document.getElementById('treesEquiv').textContent = 
    data.carbonFootprint.treesEquivalent;

  // Current watts with pulse animation
  const currentWatts = Math.round(data.totals.avgWatts || 0);
  const wattsElement = document.getElementById('currentWatts');
  
  anime({
    targets: wattsElement,
    innerHTML: [parseInt(wattsElement.textContent) || 0, currentWatts],
    round: 1,
    duration: 1500,
    easing: 'easeOutExpo'
  });

  // Update meter with animation
  updateMeterAnimated(currentWatts);

  // Update background color
  updateBackgroundColor(currentWatts);
}

// Enhanced meter update with anime.js
function updateMeterAnimated(watts) {
  const canvas = document.getElementById('meterCanvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const radius = 90;

  // Calculate angle
  const maxWatts = 2000;
  const targetAngle = Math.PI - (Math.min(watts, maxWatts) / maxWatts) * Math.PI;

  // Animate the needle rotation
  const obj = { angle: Math.PI }; // Start from bottom

  anime({
    targets: obj,
    angle: targetAngle,
    duration: 1500,
    easing: 'easeOutElastic(1, .5)',
    update: function() {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw outer circle
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
      ctx.strokeStyle = 'rgba(0, 212, 255, 0.3)';
      ctx.lineWidth = 8;
      ctx.stroke();

      // Color based on usage
      let color = '#10b981'; // Green
      if (watts > 500 && watts <= 1500) color = '#f59e0b'; // Yellow
      if (watts > 1500) color = '#ef4444'; // Red

      // Draw usage arc
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, Math.PI, obj.angle, true);
      ctx.strokeStyle = color;
      ctx.lineWidth = 8;
      ctx.stroke();

      // Draw needle
      const needleLength = radius - 10;
      const needleX = centerX + needleLength * Math.cos(obj.angle);
      const needleY = centerY + needleLength * Math.sin(obj.angle);

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(needleX, needleY);
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Draw center circle with glow
      ctx.beginPath();
      ctx.arc(centerX, centerY, 8, 0, 2 * Math.PI);
      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  });
}

// Enhanced alert animation
function updateAlerts(alerts) {
  const alertsList = document.getElementById('alertsList');
  alertsList.innerHTML = '';

  if (!alerts || alerts.length === 0) {
    alertsList.innerHTML = '<p class="no-alerts">No alerts at the moment. All good!</p>';
    return;
  }

  alerts.forEach((alert, index) => {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-item ${alert.severity}`;
    alertDiv.style.opacity = '0';
    alertDiv.innerHTML = `
      <h4>${alert.title}</h4>
      <p>${alert.message}</p>
      ${alert.recommendation ? `<p style="margin-top:8px; color:#00d4ff;">💡 ${alert.recommendation}</p>` : ''}
    `;
    alertsList.appendChild(alertDiv);

    // Animate each alert with stagger
    anime({
      targets: alertDiv,
      translateX: [100, 0],
      opacity: [0, 1],
      duration: 600,
      delay: index * 100,
      easing: 'easeOutExpo'
    });
  });
}
