// API Wrapper - Simple fetch functions
const API_BASE = 'http://localhost:5000/api';

// Get token from localStorage
function getToken() {
  return localStorage.getItem('token');
}

// Generic API call
async function apiCall(endpoint, method = 'GET', body = null) {
  const headers = {
    'Content-Type': 'application/json'
  };

  const token = getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config = {
    method,
    headers
  };

  if (body) {
    config.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, config);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'API call failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// Auth API
const auth = {
  register: (name, email, password) => 
    apiCall('/auth/register', 'POST', { name, email, password }),
  
  login: (email, password) => 
    apiCall('/auth/login', 'POST', { email, password }),
  
  getMe: () => apiCall('/auth/me')
};

// Home API
const homes = {
  getAll: () => apiCall('/homes'),
  getOne: (id) => apiCall(`/homes/${id}`),
  create: (data) => apiCall('/homes', 'POST', data),
  addRoom: (homeId, roomData) => apiCall(`/homes/${homeId}/rooms`, 'POST', roomData),
  addDevice: (homeId, roomId, deviceData) => 
    apiCall(`/homes/${homeId}/rooms/${roomId}/devices`, 'POST', deviceData)
};

// Reading API
const readings = {
  create: (data) => apiCall('/readings', 'POST', data),
  createBatch: (homeId, readings) => 
    apiCall('/readings/batch', 'POST', { homeId, readings }),
  getLatest: (homeId) => apiCall(`/readings/latest/${homeId}`)
};

// Analytics API
const analytics = {
  getDashboard: (homeId, period = 'today') => 
    apiCall(`/analytics/dashboard/${homeId}?period=${period}`),
  getHeatmap: (homeId, month) => 
    apiCall(`/analytics/heatmap/${homeId}?month=${month}`),
  getDeviceAnalytics: (homeId, deviceId, days = 7) => 
    apiCall(`/analytics/device/${homeId}/${deviceId}?days=${days}`)
};
